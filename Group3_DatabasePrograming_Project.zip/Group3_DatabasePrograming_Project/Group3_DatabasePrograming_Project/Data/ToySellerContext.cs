﻿using Group3_DatabasePrograming_Project.Models;
using Microsoft.EntityFrameworkCore;
namespace Group3_DatabasePrograming_Project.Data
{
    public class ToySellerContext : DbContext
    { // ประกาศคลาสบริบท
        public DbSet<Category> Categorys { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<Guest> Guests { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-9TLOG18;Database=ToySeller;Trusted_Connection=True ;TrustServerCertificate=True;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
            .Property(p => p.ProductName)
            .HasDefaultValue(0); // EF จะสร้างสคริปต์SQL เป็น DEFAULT 0
        }
    }
}