﻿using Group3_DatabasePrograming_Project.Data;
using Group3_DatabasePrograming_Project.Models;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormShop : Form
    {
        public class CartItem
        {
            public int PId { get; set; }
            public string PName { get; set; }
            public decimal UnitPrice { get; set; }
            public int Quantity { get; set; }

            public decimal total => UnitPrice * Quantity;
        }

        private int? member = null;
        private int? _guest = null;
        private int selecting = 0;
        private int usepoint = 0;
        private int _nowpoint = 0;
        private List<CartItem> _cart = new List<CartItem>();
        public FormShop()
        {
            InitializeComponent();
        }

        private void FormShop_Load(object sender, EventArgs e)
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var g = new Guest { };
                    db.Guests.Add(g);
                    db.SaveChanges();
                    _guest = g.GuestId;
                    labelUser.Text = "ชื่อผู้ใช้: ผู้เยี่ยมชม " + _guest.ToString();
                }
                InsertComboBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InsertComboBox()
        {
            using (var db = new ToySellerContext())
            {
                comboProduct.DataSource = db.Products.Where(p => p.Status == "พร้อมขาย").ToList();
                comboProduct.DisplayMember = "ProductName";
                comboProduct.ValueMember = "ProductId";
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textName.Text))
            {
                MessageBox.Show("กรุณากรอกชื่อจริง");
                return;
            }
            if (string.IsNullOrEmpty(textPhone.Text))
            {
                MessageBox.Show("กรุณากรอกเบอร์โทรศัพท์");
                return;
            }
            try
            {
                using (var db = new ToySellerContext())
                {
                    var user = db.Customers.Where(c => c.CustomerFirstName == textName.Text)
                                            .Where(c => c.CustomerPhone == textPhone.Text).FirstOrDefault();
                    if (user == null)
                    {
                        MessageBox.Show("ไม่พบสมาชิก");
                        return;
                    }
                    MessageBox.Show("เข้าสู่ระบบสำเร็จ!");
                    _guest = null;
                    member = user.CustomerId;
                    labelUser.Text = "ชื่อผู้ใช้: " + user.CustomerFirstName + " " + user.CustomerLastName;
                    labelPoints.Text = "คะแนนสะสม: " + user.CustomerPoints.ToString();
                    _nowpoint = user.CustomerPoints;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CalculateTotal()
        {
            decimal total = _cart.Sum(i => i.total) - usepoint;
            labelTotal.Text = "ยอดเงินรวม: " + total.ToString() + " บาท";
        }

        private void btnAddCart_Click(object sender, EventArgs e)
        {
            var product = (Product)comboProduct.SelectedItem;
            int qty = (int)numericAmount.Value;

            _cart.Add(new CartItem
            {
                PId = product.ProductId,
                PName = product.ProductName,
                UnitPrice = product.SellingPrice,
                Quantity = qty,
            });
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = _cart;
            CalculateTotal();
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var item = (CartItem)dataGridView1.CurrentRow.DataBoundItem;
                _cart.Remove(item);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = _cart;
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            if (_cart.Count > 0)
            {
                _cart.Clear();

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = _cart;
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (_cart.Count == 0) return;
            bool paymentdone = false;
            if (string.IsNullOrEmpty(comboPayment.Text))
            {
                MessageBox.Show("กรุณาเลือกวิธีการชำระเงิน");
                return;
            }
            if (comboPayment.Text == "PromptPay")
            {
                using (FormQR frmQ = new FormQR())
                {
                    if (frmQ.ShowDialog() == DialogResult.OK)
                    {
                        paymentdone = true;
                    }
                }
            }
            if (comboPayment.Text == "Credit Card")
            {
                using (FormCreditCard frmC = new FormCreditCard())
                {
                    if (frmC.ShowDialog() == DialogResult.OK)
                    {
                        paymentdone = true;
                    }
                }
            }
            bool ismem = false;
            if (member != null)
            {
                ismem = true;
            }
            MessageBox.Show(paymentdone.ToString());
            if (paymentdone)
            {
                using (var db = new ToySellerContext())
                {
                    using (var transaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var newOrder = new Order
                            {
                                OrderDate = DateTime.Now,
                                IsMember = ismem,
                                CustomerId = member,
                                GuestId = _guest,
                                Total = _cart.Sum(i => i.total)
                            };

                            db.Orders.Add(newOrder);
                            db.SaveChanges();

                            foreach (var item in _cart)
                            {
                                var detail = new OrderDetail
                                {
                                    OrderId = newOrder.OrderId,
                                    ProductId = item.PId,
                                    Quantity = item.Quantity,
                                    UnitPrice = item.UnitPrice,
                                };
                                db.OrderDetails.Add(detail);

                                var productInDb = db.Products.Find(item.PId);
                                if (productInDb.StockQty < item.Quantity)
                                {
                                    throw new Exception($"สินค้า {item.PName} ไม่เพียงพอ");
                                }
                                productInDb.StockQty -= item.Quantity;
                            }
                            db.SaveChanges();
                            if (ismem)
                            {
                                var point = db.Customers.Find(member);
                                if (point != null)
                                {
                                    point.CustomerPoints = point.CustomerPoints - _nowpoint;
                                    point.CustomerPoints = point.CustomerPoints + (Convert.ToInt32(newOrder.Total) / 25);
                                }
                            }
                            db.SaveChanges();
                            transaction.Commit();

                            MessageBox.Show("บันทึกการขายสำเร็จ");

                            _cart.Clear();
                            dataGridView1.DataSource = null;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("เกิดข้อผิดพลาด" + ex.Message);
                        }
                    }
                }
            }
        }

        private void buttonReg_Click(object sender, EventArgs e)
        {
            FormRegister frm = new FormRegister();
            frm.ShowDialog();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value > _nowpoint)
            {
                numericUpDown1.Value = _nowpoint;
                return;
            }
            usepoint = Convert.ToInt32(numericUpDown1.Value);
            CalculateTotal();
        }
    }
}
