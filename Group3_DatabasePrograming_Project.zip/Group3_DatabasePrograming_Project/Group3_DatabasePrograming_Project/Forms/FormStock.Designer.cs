﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            buttonReceive = new Button();
            textAmount = new TextBox();
            label1 = new Label();
            labelSelecting = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(322, 210);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dgv_CellClick;
            dataGridView1.CellFormatting += dgv_CellFormatiing;
            // 
            // buttonReceive
            // 
            buttonReceive.Location = new Point(213, 268);
            buttonReceive.Name = "buttonReceive";
            buttonReceive.Size = new Size(121, 23);
            buttonReceive.TabIndex = 1;
            buttonReceive.Text = "รับสินค้า";
            buttonReceive.UseVisualStyleBackColor = true;
            buttonReceive.Click += buttonReceive_Click;
            // 
            // textAmount
            // 
            textAmount.BorderStyle = BorderStyle.FixedSingle;
            textAmount.Location = new Point(213, 239);
            textAmount.Name = "textAmount";
            textAmount.Size = new Size(121, 23);
            textAmount.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(167, 243);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 3;
            label1.Text = "จำนวน:";
            // 
            // labelSelecting
            // 
            labelSelecting.AutoSize = true;
            labelSelecting.Location = new Point(12, 241);
            labelSelecting.Name = "labelSelecting";
            labelSelecting.Size = new Size(80, 15);
            labelSelecting.TabIndex = 4;
            labelSelecting.Text = "กำลังเลือก: N/A";
            // 
            // FormStock
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(351, 305);
            Controls.Add(labelSelecting);
            Controls.Add(label1);
            Controls.Add(textAmount);
            Controls.Add(buttonReceive);
            Controls.Add(dataGridView1);
            Name = "FormStock";
            Text = "คลังสินค้า";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button buttonReceive;
        private TextBox textAmount;
        private Label label1;
        private Label labelSelecting;
    }
}