﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    
    public partial class FormCreditCard : Form
    {
        public FormCreditCard()
        {
            InitializeComponent();
        }
        private void buttonYes_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textCardNumber.Text))
            {
                MessageBox.Show("กรุณาระบุเลขบัตร");
                return;
            }
            if (string.IsNullOrEmpty(textMM.Text))
            {
                MessageBox.Show("กรุณาระบุเดือนหมดอายุ");
                return;
            }
            if (string.IsNullOrEmpty(textYY.Text))
            {
                MessageBox.Show("กรุณาระบุปีหมดอายุ");
                return;
            }
            if (string.IsNullOrEmpty(textCVC.Text))
            {
                MessageBox.Show("กรุณาระบุเลข CVC");
                return;
            }

        }
    }
}
