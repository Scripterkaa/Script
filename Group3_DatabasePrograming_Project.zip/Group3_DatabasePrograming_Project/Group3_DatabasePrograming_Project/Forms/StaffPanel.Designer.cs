﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class StaffPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnOrder = new Button();
            btnStock = new Button();
            btnProduct = new Button();
            btnMember = new Button();
            btnEmployee = new Button();
            btnLogout = new Button();
            btnDashBoard = new Button();
            SuspendLayout();
            // 
            // btnOrder
            // 
            btnOrder.Location = new Point(16, 12);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(170, 50);
            btnOrder.TabIndex = 0;
            btnOrder.Text = "ออเดอร์ให้ลูกค้า";
            btnOrder.UseVisualStyleBackColor = true;
            btnOrder.Click += btnOrder_Click;
            // 
            // btnStock
            // 
            btnStock.Location = new Point(16, 68);
            btnStock.Name = "btnStock";
            btnStock.Size = new Size(170, 50);
            btnStock.TabIndex = 1;
            btnStock.Text = "จัดการคลังสินค้า";
            btnStock.UseVisualStyleBackColor = true;
            btnStock.Click += btnStock_Click;
            // 
            // btnProduct
            // 
            btnProduct.Enabled = false;
            btnProduct.Location = new Point(16, 124);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(170, 50);
            btnProduct.TabIndex = 2;
            btnProduct.Text = "จัดการระบบสินค้า";
            btnProduct.UseVisualStyleBackColor = true;
            btnProduct.Click += btnProduct_Click;
            // 
            // btnMember
            // 
            btnMember.Enabled = false;
            btnMember.Location = new Point(192, 12);
            btnMember.Name = "btnMember";
            btnMember.Size = new Size(170, 50);
            btnMember.TabIndex = 3;
            btnMember.Text = "จัดการระบบสมาชิก";
            btnMember.UseVisualStyleBackColor = true;
            btnMember.Click += btnMember_Click;
            // 
            // btnEmployee
            // 
            btnEmployee.Enabled = false;
            btnEmployee.Location = new Point(192, 68);
            btnEmployee.Name = "btnEmployee";
            btnEmployee.Size = new Size(170, 50);
            btnEmployee.TabIndex = 4;
            btnEmployee.Text = "จัดการระบบพนักงาน";
            btnEmployee.UseVisualStyleBackColor = true;
            btnEmployee.Click += btnEmployee_Click;
            // 
            // btnLogout
            // 
            btnLogout.Location = new Point(147, 180);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(91, 22);
            btnLogout.TabIndex = 5;
            btnLogout.Text = "ออกจากระบบ";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // btnDashBoard
            // 
            btnDashBoard.Enabled = false;
            btnDashBoard.Location = new Point(192, 124);
            btnDashBoard.Name = "btnDashBoard";
            btnDashBoard.Size = new Size(170, 50);
            btnDashBoard.TabIndex = 6;
            btnDashBoard.Text = "สรุปผล";
            btnDashBoard.UseVisualStyleBackColor = true;
            btnDashBoard.Click += btnDashBoard_Click;
            // 
            // StaffPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(378, 218);
            Controls.Add(btnDashBoard);
            Controls.Add(btnLogout);
            Controls.Add(btnEmployee);
            Controls.Add(btnMember);
            Controls.Add(btnProduct);
            Controls.Add(btnStock);
            Controls.Add(btnOrder);
            Name = "StaffPanel";
            Text = "จัดการระบบ";
            Load += StaffPanel_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button btnOrder;
        private Button btnStock;
        private Button btnProduct;
        private Button btnMember;
        private Button btnEmployee;
        private Button btnLogout;
        private Button btnDashBoard;
    }
}