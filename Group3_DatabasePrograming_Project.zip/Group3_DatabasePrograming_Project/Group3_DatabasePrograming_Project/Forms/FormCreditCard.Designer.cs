﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormCreditCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textCardNumber = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textMM = new TextBox();
            label3 = new Label();
            textYY = new TextBox();
            label4 = new Label();
            textCVC = new TextBox();
            buttonYes = new Button();
            buttonNo = new Button();
            SuspendLayout();
            // 
            // textCardNumber
            // 
            textCardNumber.BorderStyle = BorderStyle.FixedSingle;
            textCardNumber.Location = new Point(63, 16);
            textCardNumber.MaxLength = 12;
            textCardNumber.Name = "textCardNumber";
            textCardNumber.Size = new Size(296, 23);
            textCardNumber.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 20);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 1;
            label1.Text = "เลขบัตร:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 49);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 2;
            label2.Text = "วันหมดอายุ:";
            // 
            // textMM
            // 
            textMM.BorderStyle = BorderStyle.FixedSingle;
            textMM.Location = new Point(80, 45);
            textMM.MaxLength = 2;
            textMM.Name = "textMM";
            textMM.Size = new Size(32, 23);
            textMM.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(118, 49);
            label3.Name = "label3";
            label3.Size = new Size(12, 15);
            label3.TabIndex = 4;
            label3.Text = "/";
            // 
            // textYY
            // 
            textYY.BorderStyle = BorderStyle.FixedSingle;
            textYY.Location = new Point(136, 45);
            textYY.MaxLength = 2;
            textYY.Name = "textYY";
            textYY.Size = new Size(32, 23);
            textYY.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(258, 49);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 6;
            label4.Text = "CVC:";
            // 
            // textCVC
            // 
            textCVC.BorderStyle = BorderStyle.FixedSingle;
            textCVC.Location = new Point(297, 45);
            textCVC.MaxLength = 3;
            textCVC.Name = "textCVC";
            textCVC.Size = new Size(62, 23);
            textCVC.TabIndex = 7;
            // 
            // buttonYes
            // 
            buttonYes.DialogResult = DialogResult.OK;
            buttonYes.Location = new Point(203, 76);
            buttonYes.Name = "buttonYes";
            buttonYes.Size = new Size(75, 23);
            buttonYes.TabIndex = 8;
            buttonYes.Text = "ยืนยัน";
            buttonYes.UseVisualStyleBackColor = true;
            buttonYes.Click += buttonYes_Click;
            // 
            // buttonNo
            // 
            buttonNo.DialogResult = DialogResult.Cancel;
            buttonNo.Location = new Point(284, 76);
            buttonNo.Name = "buttonNo";
            buttonNo.Size = new Size(75, 23);
            buttonNo.TabIndex = 9;
            buttonNo.Text = "ยกเลิก";
            buttonNo.UseVisualStyleBackColor = true;
            // 
            // FormCreditCard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(371, 108);
            Controls.Add(buttonNo);
            Controls.Add(buttonYes);
            Controls.Add(textCVC);
            Controls.Add(label4);
            Controls.Add(textYY);
            Controls.Add(label3);
            Controls.Add(textMM);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textCardNumber);
            Name = "FormCreditCard";
            Text = "กรุณาข้อมูล Credit Card";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textCardNumber;
        private Label label1;
        private Label label2;
        private TextBox textMM;
        private Label label3;
        private TextBox textYY;
        private Label label4;
        private TextBox textCVC;
        private Button buttonYes;
        private Button buttonNo;
    }
}