namespace Group3_DatabasePrograming_Project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public string user => textUser.Text;
        public string pass => textPass.Text;
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textUser.Text))
            {
                MessageBox.Show("กรุณากรอก username");
                return;
            }
            if (string.IsNullOrEmpty(textPass.Text))
            {
                MessageBox.Show("กรุณากรอก password");
                return;
            }
        }
    }
}
