﻿using Group3_DatabasePrograming_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormStock : Form
    {
        private int selecting = 0;
        public FormStock()
        {
            InitializeComponent();
            DataLoad();
        }
        
        private void dgv_CellFormatiing(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "StockQty")
            {
                if (e.Value != null)
                {
                    int stock = Convert.ToInt32(e.Value);

                    if (stock == 0)
                    {
                        e.CellStyle.BackColor = Color.Red;
                        e.CellStyle.ForeColor = Color.White;
                    }
                    else if (stock < 5)
                    {
                        e.CellStyle.BackColor = Color.Yellow;
                    }
                }
            }
        }

        private void DataLoad()
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var p = db.Products.Select(p => new
                    {
                        p.ProductId,
                        p.ProductName,
                        p.StockQty
                    }).ToList();
                    dataGridView1.DataSource = p;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void buttonReceive_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textAmount.Text, out int amount))
            {
                MessageBox.Show("กรุณากรอกจำนวนสินค้าเป็นตัวเลข");
                return; 
            }
            try
            {
                if (selecting == 0) { return; }
                using (var db = new ToySellerContext())
                {
                    var p = db.Products.Find(selecting);
                    if (p != null)
                    {
                        p.StockQty = p.StockQty + amount;
                    }
                    db.SaveChanges();
                    DataLoad();
                    MessageBox.Show("เพิ่มสินค้าจำนวน " + amount.ToString() + " เสร็จสิ้น");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    var row = dataGridView1.Rows[e.RowIndex];
                    selecting = Convert.ToInt16(row.Cells["ProductId"].Value);
                    using (var db = new ToySellerContext())
                    {
                        var p = db.Products.Find(selecting);
                        if (p != null)
                        {
                            labelSelecting.Text = "กำลังเลือก: " + p.ProductId + " " + p.ProductName;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
