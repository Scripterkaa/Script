﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelTotal = new Label();
            labelAmount = new Label();
            labelMember = new Label();
            labelBestSell = new Label();
            comboFilter = new ComboBox();
            label5 = new Label();
            dtMin = new DateTimePicker();
            dtMax = new DateTimePicker();
            label6 = new Label();
            label7 = new Label();
            labelMostPoint = new Label();
            buttonDateFil = new Button();
            buttonGetSellHistory = new Button();
            buttonMonth = new Button();
            buttonYear = new Button();
            SuspendLayout();
            // 
            // labelTotal
            // 
            labelTotal.AutoSize = true;
            labelTotal.Font = new Font("Segoe UI", 13F);
            labelTotal.Location = new Point(12, 118);
            labelTotal.Name = "labelTotal";
            labelTotal.Size = new Size(73, 25);
            labelTotal.TabIndex = 0;
            labelTotal.Text = "ยอดขาย:";
            // 
            // labelAmount
            // 
            labelAmount.AutoSize = true;
            labelAmount.Font = new Font("Segoe UI", 13F);
            labelAmount.Location = new Point(12, 80);
            labelAmount.Name = "labelAmount";
            labelAmount.Size = new Size(132, 25);
            labelAmount.TabIndex = 1;
            labelAmount.Text = "ขายไปแล้วจำนวน:";
            // 
            // labelMember
            // 
            labelMember.AutoSize = true;
            labelMember.Font = new Font("Segoe UI", 13F);
            labelMember.Location = new Point(12, 258);
            labelMember.Name = "labelMember";
            labelMember.Size = new Size(124, 25);
            labelMember.TabIndex = 2;
            labelMember.Text = "มีสมาชิกทั้งหมด:";
            // 
            // labelBestSell
            // 
            labelBestSell.AutoSize = true;
            labelBestSell.Font = new Font("Segoe UI", 13F);
            labelBestSell.Location = new Point(12, 155);
            labelBestSell.Name = "labelBestSell";
            labelBestSell.Size = new Size(93, 25);
            labelBestSell.TabIndex = 3;
            labelBestSell.Text = "สินค้าขายดี:";
            // 
            // comboFilter
            // 
            comboFilter.FormattingEnabled = true;
            comboFilter.Items.AddRange(new object[] { "ทั้งหมด", "กรองตามวันที่" });
            comboFilter.Location = new Point(56, 12);
            comboFilter.Name = "comboFilter";
            comboFilter.Size = new Size(105, 23);
            comboFilter.TabIndex = 4;
            comboFilter.SelectedIndexChanged += comboFilter_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(14, 15);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 5;
            label5.Text = "Filter:";
            // 
            // dtMin
            // 
            dtMin.Enabled = false;
            dtMin.Format = DateTimePickerFormat.Short;
            dtMin.Location = new Point(56, 39);
            dtMin.Name = "dtMin";
            dtMin.Size = new Size(105, 23);
            dtMin.TabIndex = 6;
            // 
            // dtMax
            // 
            dtMax.Enabled = false;
            dtMax.Format = DateTimePickerFormat.Short;
            dtMax.Location = new Point(195, 39);
            dtMax.Name = "dtMax";
            dtMax.Size = new Size(105, 23);
            dtMax.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(21, 43);
            label6.Name = "label6";
            label6.Size = new Size(29, 15);
            label6.TabIndex = 8;
            label6.Text = "วันที่:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(167, 43);
            label7.Name = "label7";
            label7.Size = new Size(22, 15);
            label7.TabIndex = 9;
            label7.Text = "ถึง:";
            // 
            // labelMostPoint
            // 
            labelMostPoint.AutoSize = true;
            labelMostPoint.Font = new Font("Segoe UI", 13F);
            labelMostPoint.Location = new Point(14, 293);
            labelMostPoint.Name = "labelMostPoint";
            labelMostPoint.Size = new Size(176, 25);
            labelMostPoint.TabIndex = 10;
            labelMostPoint.Text = "สมาชิกที่มีแต้มเยอะที่สุด:";
            // 
            // buttonDateFil
            // 
            buttonDateFil.Enabled = false;
            buttonDateFil.Location = new Point(306, 38);
            buttonDateFil.Name = "buttonDateFil";
            buttonDateFil.Size = new Size(71, 24);
            buttonDateFil.TabIndex = 11;
            buttonDateFil.Text = "ค้นหา";
            buttonDateFil.UseVisualStyleBackColor = true;
            buttonDateFil.Click += buttonDateFil_Click;
            // 
            // buttonGetSellHistory
            // 
            buttonGetSellHistory.Location = new Point(14, 327);
            buttonGetSellHistory.Name = "buttonGetSellHistory";
            buttonGetSellHistory.Size = new Size(102, 54);
            buttonGetSellHistory.TabIndex = 12;
            buttonGetSellHistory.Text = "ปริ้นประวัติการขายรายวัน";
            buttonGetSellHistory.UseVisualStyleBackColor = true;
            buttonGetSellHistory.Click += buttonGetSellHistory_Click;
            // 
            // buttonMonth
            // 
            buttonMonth.Location = new Point(146, 327);
            buttonMonth.Name = "buttonMonth";
            buttonMonth.Size = new Size(102, 54);
            buttonMonth.TabIndex = 13;
            buttonMonth.Text = "ปริ้นประวัติการขายรายเดือน";
            buttonMonth.UseVisualStyleBackColor = true;
            buttonMonth.Click += buttonMonth_Click;
            // 
            // buttonYear
            // 
            buttonYear.Location = new Point(275, 327);
            buttonYear.Name = "buttonYear";
            buttonYear.Size = new Size(102, 54);
            buttonYear.TabIndex = 14;
            buttonYear.Text = "ปริ้นประวัติการขายรายปี";
            buttonYear.UseVisualStyleBackColor = true;
            buttonYear.Click += buttonYear_Click;
            // 
            // FormDashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(391, 402);
            Controls.Add(buttonYear);
            Controls.Add(buttonMonth);
            Controls.Add(buttonGetSellHistory);
            Controls.Add(buttonDateFil);
            Controls.Add(labelMostPoint);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(dtMax);
            Controls.Add(dtMin);
            Controls.Add(label5);
            Controls.Add(comboFilter);
            Controls.Add(labelBestSell);
            Controls.Add(labelMember);
            Controls.Add(labelAmount);
            Controls.Add(labelTotal);
            Name = "FormDashboard";
            Text = "สรุปข้อมูล";
            Load += FormDashboard_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelTotal;
        private Label labelAmount;
        private Label labelMember;
        private Label labelBestSell;
        private ComboBox comboFilter;
        private Label label5;
        private DateTimePicker dtMin;
        private DateTimePicker dtMax;
        private Label label6;
        private Label label7;
        private Label labelMostPoint;
        private Button buttonDateFil;
        private Button buttonGetSellHistory;
        private Button buttonMonth;
        private Button buttonYear;
    }
}