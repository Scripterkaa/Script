﻿using Group3_DatabasePrograming_Project.Data;
using Group3_DatabasePrograming_Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormProduct : Form
    {
        private int selecting = 0;
        private bool editmode = false;
        public FormProduct()
        {
            InitializeComponent();
        }

        private void FormProduct_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.MultiSelect = true;
            Load_Data();
            InsertComboCategory();
            btnSave.Enabled = false;
        }

        private void Load_Data()
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var product = db.Products.Select(p => new
                    {
                        p.ProductId,
                        p.ProductName,
                        p.ProductDescription,
                        p.ProductHow,
                        Category = p.Category.CategoryName,
                        p.CostPrice,
                        p.SellingPrice,
                        p.StockQty,
                        p.ManufactureDate,
                        p.ExpirationDate,
                        p.Status
                    }).ToList();
                    dataGridView1.DataSource = product;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearForm()
        {
            textCategory.Text = "";
            textCost.Text = "";
            textHowto.Text = "";
            textDes.Text = "";
            textEXP.Text = "";
            textManu.Text = "";
            textPrice.Text = "";
            textName.Text = "";
            textQty.Text = "";
            comboStatus.SelectedIndex = -1;

        }

        private bool ValidateInput(out int c_id, out int p_qty, out decimal p_price, out decimal p_cost, out DateOnly p_exp, out DateOnly p_manu,out byte[]? img)
        {
            c_id = 0; p_qty = 0; p_price = 0; p_cost = 0;
            p_exp = DateOnly.Parse("01/01/2580");
            p_manu = DateOnly.Parse("01/01/2569");
            img = null;
            if (!int.TryParse(textCategory.Text, out c_id))
            {
                MessageBox.Show("กรุณาระบุ Category ID");
                return false;
            }

            if (!int.TryParse(textQty.Text, out p_qty))
            {
                MessageBox.Show("กรุณาระบุจำนวนคงเหลือ");
                return false;
            }
            if (!decimal.TryParse(textPrice.Text, out p_price))
            {
                MessageBox.Show("กรุณาระบุราคา");
                return false;
            }
            if (!decimal.TryParse(textCost.Text, out p_cost))
            {
                MessageBox.Show("กรุณาระบุราคาต้นทุน");
                return false;
            }
            if (string.IsNullOrEmpty(comboStatus.Text))
            {
                MessageBox.Show("กรุณาระบุสถานะ");
                return false;
            }
            if (string.IsNullOrEmpty(textDes.Text))
            {
                MessageBox.Show("กรุณาระบุรายละเอียดสินค้า");
                return false;
            }
            if (string.IsNullOrEmpty(textHowto.Text))
            {
                MessageBox.Show("กรุณาระบุวิธีการใช้งาน");
                return false;
            }
            if (string.IsNullOrEmpty(textName.Text))
            {
                MessageBox.Show("กรุณาระบุชื่อสินค้า");
                return false;
            }
            if (!DateOnly.TryParse(textEXP.Text, out p_exp))
            {
                MessageBox.Show("กรุณาระบุวันหมดอายุ");
                return false;
            }
            if (!DateOnly.TryParse(textManu.Text, out p_manu))
            {
                MessageBox.Show("กรุณาระบุวันหมดอายุ");
                return false;
            }
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("กรุณาใส่รูปภาพ");
                return false;
            }
            else
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                    img = ms.ToArray();
                }
            }
            return true;
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            string filter = textSearch.Text.Trim();
            try
            {
                using (var db = new ToySellerContext())
                {
                    var product = db.Products.Where(p => p.ProductName.Contains(filter)).Select(p => new
                    {

                        p.ProductId,
                        p.ProductName,
                        p.ProductDescription,
                        p.ProductHow,
                        Category = p.Category.CategoryName,
                        p.CostPrice,
                        p.SellingPrice,
                        p.StockQty,
                        p.ManufactureDate,
                        p.ExpirationDate,
                        p.Status

                    }).ToList();
                    dataGridView1.DataSource = product;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ClearForm();
            comboFilStatus.SelectedIndex = -1;
            comboCat.SelectedIndex = -1;
            textFilMax.Text = "";
            textFilMin.Text = "";
            textSearch.Text = "";
            pictureBox1.Image = null;
            Load_Data();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int c_id = 0; int p_qty = 0; decimal p_price = 0; decimal p_cost = 0;
            DateOnly p_exp = DateOnly.Parse("01/01/2026");
            DateOnly p_manu = DateOnly.Parse("01/01/2026");
            byte[]? img = null;
            if (!ValidateInput(out c_id, out p_qty, out p_price, out p_cost, out p_exp, out p_manu, out img)) { return; }

            try
            {

                using (var db = new ToySellerContext())
                {
                    var newProduct = new Product
                    {
                        ProductName = textName.Text.Trim(),
                        ProductDescription = textDes.Text.Trim(),
                        CategoryId = c_id,
                        ProductHow = textHowto.Text.Trim(),
                        ManufactureDate = p_manu,
                        ExpirationDate = p_exp,
                        CostPrice = p_cost,
                        SellingPrice = p_price,
                        Status = comboStatus.Text.Trim(),
                        StockQty = p_qty,
                        ProductImage = img,
                    };
                    db.Products.Add(newProduct);
                    db.SaveChanges();
                }
                ClearForm();
                Load_Data();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    var row = dataGridView1.Rows[e.RowIndex];
                    selecting = Convert.ToInt16(row.Cells["ProductId"].Value);
                    using (var db = new ToySellerContext())
                    {
                        var p = db.Products.Find(selecting);
                        if (p != null)
                        {
                            labelID.Text = "รหัสสินค้า: " + p.ProductId.ToString();
                            textName.Text = p.ProductName;
                            textDes.Text = p.ProductDescription;
                            textCategory.Text = p.CategoryId.ToString();
                            textHowto.Text = p.ProductHow;
                            textCost.Text = p.CostPrice.ToString();
                            textEXP.Text = p.ExpirationDate.ToString();
                            textManu.Text = p.ManufactureDate.ToString();
                            textPrice.Text = p.SellingPrice.ToString();
                            textQty.Text = p.StockQty.ToString();
                            comboStatus.Text = p.Status.ToString();
                            using (MemoryStream ms = new MemoryStream(p.ProductImage))
                            {
                                pictureBox1.Image = Image.FromStream(ms);
                                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (selecting == 0)
            {
                MessageBox.Show("กรุณาเลือกรายการที่จะลบ");
                return;
            }
            try
            {
                if (MessageBox.Show("ยืนยันการลบ?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    using (var db = new ToySellerContext())
                    {
                        var p = db.Products.Find(selecting);
                        if (p != null)
                        {
                            db.Products.Remove(p);
                            db.SaveChanges();
                            Load_Data();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (editmode)
            {
                editmode = false;
                btnEdit.Text = "โหมดแก้ไขสินค้า";
                btnSave.Enabled = false;
                btnAdd.Enabled = true;
                btnRemove.Enabled = true;
            }
            else
            {
                editmode = true;
                btnEdit.Text = "ยกเลิก";
                btnSave.Enabled = true;
                btnAdd.Enabled = false;
                btnRemove.Enabled = false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (selecting != 0)
            {
                int c_id = 0; int p_qty = 0; decimal p_price = 0; decimal p_cost = 0;
                DateOnly p_exp = DateOnly.Parse("01/01/2026");
                DateOnly p_manu = DateOnly.Parse("01/01/2026");
                byte[]? img = null;
                if (!ValidateInput(out c_id, out p_qty, out p_price, out p_cost, out p_exp, out p_manu, out img)) { return; }

                try
                {

                    using (var db = new ToySellerContext())
                    {
                        var p = db.Products.Find(selecting);
                        if (p != null)
                        {
                            p.ProductName = textName.Text.Trim();
                            p.ProductDescription = textDes.Text.Trim();
                            p.CategoryId = c_id;
                            p.ProductHow = textHowto.Text.Trim();
                            p.ManufactureDate = p_manu;
                            p.ExpirationDate = p_exp;
                            p.CostPrice = p_cost;
                            p.SellingPrice = p_price;
                            p.Status = comboStatus.Text.Trim();
                            p.StockQty = p_qty;
                            p.ProductImage = img;
                        }
                        ;
                        db.SaveChanges();
                    }
                    ClearForm();
                    Load_Data();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void InsertComboCategory()
        {
            using (var db = new ToySellerContext())
            {
                var _c = db.Categorys;
                foreach (var c in _c)
                {
                    comboCat.Items.Add(c.CategoryName);
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var db = new ToySellerContext())
            {
                var p = db.Products.AsQueryable();

                if (comboCat.Text != "")
                {
                    p = p.Where(p => p.Category.CategoryName == comboCat.Text);
                }
                if (decimal.TryParse(textFilMin.Text, out decimal min))
                {
                    p = p.Where(p => p.SellingPrice >= Convert.ToDecimal(min));
                }
                if (decimal.TryParse(textFilMax.Text, out decimal max))
                {
                    p = p.Where(p => p.SellingPrice <= Convert.ToDecimal(max));
                }
                if (comboFilStatus.Text != "")
                {
                    p = p.Where(p => p.Status == comboFilStatus.Text);
                }
                var result = p.Select(p => new
                {
                    p.ProductId,
                    p.ProductName,
                    p.ProductDescription,
                    p.ProductHow,
                    Category = p.Category.CategoryName,
                    p.CostPrice,
                    p.SellingPrice,
                    p.StockQty,
                    p.ManufactureDate,
                    p.ExpirationDate,
                    p.Status
                }).ToList();
                dataGridView1.DataSource = result;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.tif;";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = Image.FromFile(ofd.FileName);
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                }
            }
        }
    }
}
