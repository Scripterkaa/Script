﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textName = new TextBox();
            textPhone = new TextBox();
            btnLogin = new Button();
            btnAddCart = new Button();
            labelUser = new Label();
            label1 = new Label();
            numericAmount = new NumericUpDown();
            comboProduct = new ComboBox();
            labelTotal = new Label();
            buttonRemove = new Button();
            buttonClear = new Button();
            buttonSave = new Button();
            buttonReg = new Button();
            comboPayment = new ComboBox();
            label2 = new Label();
            labelPoints = new Label();
            label3 = new Label();
            numericUpDown1 = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericAmount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(16, 145);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(471, 146);
            dataGridView1.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 68);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 5;
            label4.Text = "ชื่อจริง:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(212, 68);
            label5.Name = "label5";
            label5.Size = new Size(70, 15);
            label5.TabIndex = 6;
            label5.Text = "เบอร์โทรศัพท์:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(13, 45);
            label6.Name = "label6";
            label6.Size = new Size(380, 15);
            label6.TabIndex = 7;
            label6.Text = "*หากท่านเป็นสมาชิก กรุณากรอกชื่อและเบอร์โทรศัพท์เพื่อสะสมหรือใช้งานแต้มส่วนลด";
            // 
            // textName
            // 
            textName.BorderStyle = BorderStyle.FixedSingle;
            textName.Location = new Point(58, 65);
            textName.Name = "textName";
            textName.Size = new Size(139, 23);
            textName.TabIndex = 8;
            // 
            // textPhone
            // 
            textPhone.BorderStyle = BorderStyle.FixedSingle;
            textPhone.Location = new Point(288, 63);
            textPhone.Name = "textPhone";
            textPhone.Size = new Size(119, 23);
            textPhone.TabIndex = 9;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(413, 63);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(80, 23);
            btnLogin.TabIndex = 10;
            btnLogin.Text = "เข้าสู่ระบบ";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnAddCart
            // 
            btnAddCart.Location = new Point(413, 102);
            btnAddCart.Name = "btnAddCart";
            btnAddCart.Size = new Size(80, 27);
            btnAddCart.TabIndex = 13;
            btnAddCart.Text = "ใส่ตะกร้า";
            btnAddCart.UseVisualStyleBackColor = true;
            btnAddCart.Click += btnAddCart_Click;
            // 
            // labelUser
            // 
            labelUser.AutoSize = true;
            labelUser.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelUser.Location = new Point(12, 9);
            labelUser.Name = "labelUser";
            labelUser.Size = new Size(120, 30);
            labelUser.TabIndex = 14;
            labelUser.Text = "ชื่อผู้ใช้: N/A";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(242, 108);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 16;
            label1.Text = "ใส่ตะกร้าจำนวน:";
            // 
            // numericAmount
            // 
            numericAmount.Location = new Point(327, 105);
            numericAmount.Name = "numericAmount";
            numericAmount.Size = new Size(80, 23);
            numericAmount.TabIndex = 17;
            // 
            // comboProduct
            // 
            comboProduct.FormattingEnabled = true;
            comboProduct.Location = new Point(16, 105);
            comboProduct.Name = "comboProduct";
            comboProduct.Size = new Size(220, 23);
            comboProduct.TabIndex = 18;
            // 
            // labelTotal
            // 
            labelTotal.AutoSize = true;
            labelTotal.Location = new Point(16, 309);
            labelTotal.Name = "labelTotal";
            labelTotal.Size = new Size(86, 15);
            labelTotal.TabIndex = 19;
            labelTotal.Text = "ยอดเงินรวม: N/A";
            // 
            // buttonRemove
            // 
            buttonRemove.Location = new Point(321, 345);
            buttonRemove.Name = "buttonRemove";
            buttonRemove.Size = new Size(80, 27);
            buttonRemove.TabIndex = 20;
            buttonRemove.Text = "ลบ";
            buttonRemove.UseVisualStyleBackColor = true;
            buttonRemove.Click += buttonRemove_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(407, 345);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(80, 27);
            buttonClear.TabIndex = 21;
            buttonClear.Text = "ล้าง";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(321, 376);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(166, 27);
            buttonSave.TabIndex = 22;
            buttonSave.Text = "บันทึกธุรกรรม";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // buttonReg
            // 
            buttonReg.Location = new Point(413, 37);
            buttonReg.Name = "buttonReg";
            buttonReg.Size = new Size(80, 23);
            buttonReg.TabIndex = 23;
            buttonReg.Text = "สมัครสมาชิก";
            buttonReg.UseVisualStyleBackColor = true;
            buttonReg.Click += buttonReg_Click;
            // 
            // comboPayment
            // 
            comboPayment.FormattingEnabled = true;
            comboPayment.Items.AddRange(new object[] { "PromptPay", "Credit Card" });
            comboPayment.Location = new Point(386, 306);
            comboPayment.Name = "comboPayment";
            comboPayment.Size = new Size(101, 23);
            comboPayment.TabIndex = 24;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(306, 309);
            label2.Name = "label2";
            label2.Size = new Size(74, 15);
            label2.TabIndex = 25;
            label2.Text = "วิธีการชำระเงิน:";
            // 
            // labelPoints
            // 
            labelPoints.AutoSize = true;
            labelPoints.Location = new Point(16, 345);
            labelPoints.Name = "labelPoints";
            labelPoints.Size = new Size(73, 15);
            labelPoints.TabIndex = 26;
            labelPoints.Text = "คะแนนสะสม: 0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 378);
            label3.Name = "label3";
            label3.Size = new Size(53, 15);
            label3.TabIndex = 27;
            label3.Text = "ใช้คะแนน:";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(78, 376);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(54, 23);
            numericUpDown1.TabIndex = 28;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // FormShop
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(499, 415);
            Controls.Add(numericUpDown1);
            Controls.Add(label3);
            Controls.Add(labelPoints);
            Controls.Add(label2);
            Controls.Add(comboPayment);
            Controls.Add(buttonReg);
            Controls.Add(buttonSave);
            Controls.Add(buttonClear);
            Controls.Add(buttonRemove);
            Controls.Add(labelTotal);
            Controls.Add(comboProduct);
            Controls.Add(numericAmount);
            Controls.Add(label1);
            Controls.Add(labelUser);
            Controls.Add(btnAddCart);
            Controls.Add(btnLogin);
            Controls.Add(textPhone);
            Controls.Add(textName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Name = "FormShop";
            Text = "สั่งซื้อสินค้า";
            Load += FormShop_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericAmount).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textName;
        private TextBox textPhone;
        private Button btnLogin;
        private Button btnAddCart;
        private Label labelUser;
        private Label label1;
        private NumericUpDown numericAmount;
        private ComboBox comboProduct;
        private Label labelTotal;
        private Button buttonRemove;
        private Button buttonClear;
        private Button buttonSave;
        private Button buttonReg;
        private ComboBox comboPayment;
        private Label label2;
        private Label labelPoints;
        private Label label3;
        private NumericUpDown numericUpDown1;
    }
}