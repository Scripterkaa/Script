﻿using Group3_DatabasePrograming_Project.Data;
using Group3_DatabasePrograming_Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormRegister : Form
    {
        public FormRegister()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                try
                {
                    using (var db = new ToySellerContext())
                    {
                        var newCustomer = new Customer
                        {
                            CustomerFirstName = textFName.Text.Trim(),
                            CustomerLastName = textLName.Text.Trim(),
                            CustomerAddress = textAddress.Text.Trim(),
                            CustomerEmail = textEmail.Text.Trim(),
                            CustomerPhone = textPhone.Text.Trim(),
                            CustomerPoints = 0,
                            CustomerTaxAddress = textTaxAddress.Text.Trim(),
                            IsActive = true,
                        };

                        db.Customers.Add(newCustomer);
                        db.SaveChanges();

                        MessageBox.Show("สมัครเรียบร้อย!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrEmpty(textFName.Text))
            {
                MessageBox.Show("กรุณากรอกชื่อจริง");
            }
            if (string.IsNullOrEmpty(textLName.Text))
            {
                MessageBox.Show("กรุณากรอกนามสกุล");
            }
            if (string.IsNullOrEmpty(textEmail.Text))
            {
                MessageBox.Show("กรุณากรอกอีเมล");
            }
            if (string.IsNullOrEmpty(textPhone.Text))
            {
                MessageBox.Show("กรุณากรอกเบอร์ติดต่อ");
            }
            if (string.IsNullOrEmpty(textAddress.Text))
            {
                MessageBox.Show("กรุณากรอกที่อยู่จัดส่ง");
            }
            if (string.IsNullOrEmpty(textTaxAddress.Text))
            {
                MessageBox.Show("กรุณากรอกที่อยู่ใบเสร็จ");
            }
            return true;
        }

        private void checkSameLocation_CheckedChanged(object sender, EventArgs e)
        {
            if (checkSameLocation.Checked)
            {
                textTaxAddress.Text = textAddress.Text;
            }
            else
            {
                textTaxAddress.Text = "";
            }
        }

        private void textAddress_TextChanged(object sender, EventArgs e)
        {
            if (checkSameLocation.Checked)
            {
                textTaxAddress.Text = textAddress.Text;
            }
        }
    }
}
