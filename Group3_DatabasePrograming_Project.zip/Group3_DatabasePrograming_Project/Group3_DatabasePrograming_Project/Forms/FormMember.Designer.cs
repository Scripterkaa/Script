﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnAdd = new Button();
            btnRemove = new Button();
            btnEdit = new Button();
            btnSave = new Button();
            label1 = new Label();
            label2 = new Label();
            textName = new TextBox();
            textLName = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textPhone = new TextBox();
            textEmail = new TextBox();
            textAddress = new TextBox();
            textTaxAddress = new TextBox();
            checkSameLocation = new CheckBox();
            labelID = new Label();
            label7 = new Label();
            textSearch = new TextBox();
            label8 = new Label();
            label9 = new Label();
            textFilMin = new TextBox();
            label10 = new Label();
            textFilMax = new TextBox();
            btnFilter = new Button();
            btnResetFil = new Button();
            label11 = new Label();
            textPoints = new TextBox();
            checkIsActive = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 43);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(554, 252);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dgv_CellClick;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(506, 316);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(140, 37);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "เพิ่มสมาชิก";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(506, 359);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(140, 37);
            btnRemove.TabIndex = 2;
            btnRemove.Text = "ลบสมาชิก";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(506, 402);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(140, 37);
            btnEdit.TabIndex = 3;
            btnEdit.Text = "โหมดแก้ไข";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(506, 445);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(140, 37);
            btnSave.TabIndex = 4;
            btnSave.Text = "บันทึก";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 312);
            label1.Name = "label1";
            label1.Size = new Size(23, 15);
            label1.TabIndex = 5;
            label1.Text = "ชื่อ:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(195, 312);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 6;
            label2.Text = "นามสกุล:";
            // 
            // textName
            // 
            textName.BorderStyle = BorderStyle.FixedSingle;
            textName.Location = new Point(42, 309);
            textName.Name = "textName";
            textName.Size = new Size(141, 23);
            textName.TabIndex = 7;
            // 
            // textLName
            // 
            textLName.BorderStyle = BorderStyle.FixedSingle;
            textLName.Location = new Point(249, 310);
            textLName.Name = "textLName";
            textLName.Size = new Size(122, 23);
            textLName.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(195, 357);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 9;
            label3.Text = "เบอร์โทรศัพท์:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 355);
            label4.Name = "label4";
            label4.Size = new Size(32, 15);
            label4.TabIndex = 10;
            label4.Text = "อีเมล:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 418);
            label5.Name = "label5";
            label5.Size = new Size(53, 15);
            label5.TabIndex = 11;
            label5.Text = "ที่อยู่จัดส่ง:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(13, 461);
            label6.Name = "label6";
            label6.Size = new Size(78, 15);
            label6.TabIndex = 12;
            label6.Text = "ที่อยู่ออกใบเสร็จ:";
            // 
            // textPhone
            // 
            textPhone.BorderStyle = BorderStyle.FixedSingle;
            textPhone.Location = new Point(271, 353);
            textPhone.Name = "textPhone";
            textPhone.Size = new Size(221, 23);
            textPhone.TabIndex = 13;
            // 
            // textEmail
            // 
            textEmail.BorderStyle = BorderStyle.FixedSingle;
            textEmail.Location = new Point(51, 353);
            textEmail.Name = "textEmail";
            textEmail.Size = new Size(132, 23);
            textEmail.TabIndex = 14;
            // 
            // textAddress
            // 
            textAddress.BorderStyle = BorderStyle.FixedSingle;
            textAddress.Location = new Point(72, 416);
            textAddress.Name = "textAddress";
            textAddress.Size = new Size(420, 23);
            textAddress.TabIndex = 15;
            textAddress.TextChanged += textAddress_TextChanged;
            // 
            // textTaxAddress
            // 
            textTaxAddress.BorderStyle = BorderStyle.FixedSingle;
            textTaxAddress.Location = new Point(97, 459);
            textTaxAddress.Name = "textTaxAddress";
            textTaxAddress.Size = new Size(395, 23);
            textTaxAddress.TabIndex = 16;
            // 
            // checkSameLocation
            // 
            checkSameLocation.AutoSize = true;
            checkSameLocation.Location = new Point(13, 387);
            checkSameLocation.Name = "checkSameLocation";
            checkSameLocation.Size = new Size(80, 19);
            checkSameLocation.TabIndex = 17;
            checkSameLocation.Text = "ที่อยู่เดียวกัน";
            checkSameLocation.UseVisualStyleBackColor = true;
            checkSameLocation.CheckedChanged += checkSameLocation_CheckedChanged;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Font = new Font("Segoe UI", 15F);
            labelID.Location = new Point(13, 9);
            labelID.Name = "labelID";
            labelID.Size = new Size(143, 28);
            labelID.TabIndex = 18;
            labelID.Text = "รหัสสมาชิก: N/A";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 15F);
            label7.Location = new Point(266, 9);
            label7.Name = "label7";
            label7.Size = new Size(84, 28);
            label7.TabIndex = 19;
            label7.Text = "ค้นหาชื่อ:";
            // 
            // textSearch
            // 
            textSearch.BorderStyle = BorderStyle.FixedSingle;
            textSearch.Location = new Point(356, 14);
            textSearch.Name = "textSearch";
            textSearch.Size = new Size(210, 23);
            textSearch.TabIndex = 20;
            textSearch.TextChanged += textSearch_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F);
            label8.Location = new Point(572, 15);
            label8.Name = "label8";
            label8.Size = new Size(79, 21);
            label8.TabIndex = 21;
            label8.Text = "กรองข้อมูล:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(573, 43);
            label9.Name = "label9";
            label9.Size = new Size(73, 15);
            label9.TabIndex = 22;
            label9.Text = "คะแนนสมาชิก:";
            // 
            // textFilMin
            // 
            textFilMin.BorderStyle = BorderStyle.FixedSingle;
            textFilMin.Location = new Point(577, 67);
            textFilMin.Name = "textFilMin";
            textFilMin.Size = new Size(61, 23);
            textFilMin.TabIndex = 23;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(598, 93);
            label10.Name = "label10";
            label10.Size = new Size(19, 15);
            label10.TabIndex = 24;
            label10.Text = "ถึง";
            // 
            // textFilMax
            // 
            textFilMax.BorderStyle = BorderStyle.FixedSingle;
            textFilMax.Location = new Point(577, 111);
            textFilMax.Name = "textFilMax";
            textFilMax.Size = new Size(61, 23);
            textFilMax.TabIndex = 25;
            // 
            // btnFilter
            // 
            btnFilter.Location = new Point(577, 140);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new Size(61, 25);
            btnFilter.TabIndex = 26;
            btnFilter.Text = "ค้นหา";
            btnFilter.UseVisualStyleBackColor = true;
            btnFilter.Click += btnFilter_Click;
            // 
            // btnResetFil
            // 
            btnResetFil.Location = new Point(577, 171);
            btnResetFil.Name = "btnResetFil";
            btnResetFil.Size = new Size(61, 25);
            btnResetFil.TabIndex = 27;
            btnResetFil.Text = "รีเซ็ท";
            btnResetFil.UseVisualStyleBackColor = true;
            btnResetFil.Click += btnResetFil_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(377, 312);
            label11.Name = "label11";
            label11.Size = new Size(41, 15);
            label11.TabIndex = 28;
            label11.Text = "คะแนน:";
            // 
            // textPoints
            // 
            textPoints.BorderStyle = BorderStyle.FixedSingle;
            textPoints.Location = new Point(424, 310);
            textPoints.Name = "textPoints";
            textPoints.Size = new Size(68, 23);
            textPoints.TabIndex = 29;
            // 
            // checkIsActive
            // 
            checkIsActive.AutoSize = true;
            checkIsActive.Location = new Point(433, 391);
            checkIsActive.Name = "checkIsActive";
            checkIsActive.Size = new Size(59, 19);
            checkIsActive.TabIndex = 30;
            checkIsActive.Text = "Active";
            checkIsActive.UseVisualStyleBackColor = true;
            // 
            // FormMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(652, 501);
            Controls.Add(checkIsActive);
            Controls.Add(textPoints);
            Controls.Add(label11);
            Controls.Add(btnResetFil);
            Controls.Add(btnFilter);
            Controls.Add(textFilMax);
            Controls.Add(label10);
            Controls.Add(textFilMin);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(textSearch);
            Controls.Add(label7);
            Controls.Add(labelID);
            Controls.Add(checkSameLocation);
            Controls.Add(textTaxAddress);
            Controls.Add(textAddress);
            Controls.Add(textEmail);
            Controls.Add(textPhone);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textLName);
            Controls.Add(textName);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnSave);
            Controls.Add(btnEdit);
            Controls.Add(btnRemove);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Name = "FormMember";
            Text = "จัดการสมาชิก";
            Load += FormMember_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnAdd;
        private Button btnRemove;
        private Button btnEdit;
        private Button btnSave;
        private Label label1;
        private Label label2;
        private TextBox textName;
        private TextBox textLName;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textPhone;
        private TextBox textEmail;
        private TextBox textAddress;
        private TextBox textTaxAddress;
        private CheckBox checkSameLocation;
        private Label labelID;
        private Label label7;
        private TextBox textSearch;
        private Label label8;
        private Label label9;
        private TextBox textFilMin;
        private Label label10;
        private TextBox textFilMax;
        private Button btnFilter;
        private Button btnResetFil;
        private Label label11;
        private TextBox textPoints;
        private CheckBox checkIsActive;
    }
}