﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormQR : Form
    {
        public FormQR()
        {
            InitializeComponent();
        }
    }
}
