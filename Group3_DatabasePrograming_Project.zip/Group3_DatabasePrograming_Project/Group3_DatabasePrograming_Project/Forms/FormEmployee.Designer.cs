﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            labelID = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textName = new TextBox();
            comboRole = new ComboBox();
            textUser = new TextBox();
            textPass = new TextBox();
            buttonAdd = new Button();
            buttonRemove = new Button();
            buttonEdit = new Button();
            buttonSave = new Button();
            comboIsActive = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(426, 209);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dgv_CellClick;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Location = new Point(12, 237);
            labelID.Name = "labelID";
            labelID.Size = new Size(92, 15);
            labelID.TabIndex = 1;
            labelID.Text = "รหัสพนักงาน: N/A";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 270);
            label2.Name = "label2";
            label2.Size = new Size(23, 15);
            label2.TabIndex = 2;
            label2.Text = "ชื่อ:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 299);
            label3.Name = "label3";
            label3.Size = new Size(47, 15);
            label3.TabIndex = 3;
            label3.Text = "ตำแหน่ง:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 331);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 4;
            label4.Text = "สถานะ:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(214, 270);
            label5.Name = "label5";
            label5.Size = new Size(43, 15);
            label5.TabIndex = 5;
            label5.Text = "ยูสเซอร์:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(214, 299);
            label6.Name = "label6";
            label6.Size = new Size(47, 15);
            label6.TabIndex = 6;
            label6.Text = "รหัสผ่าน:";
            // 
            // textName
            // 
            textName.BorderStyle = BorderStyle.FixedSingle;
            textName.Location = new Point(41, 267);
            textName.Name = "textName";
            textName.Size = new Size(159, 23);
            textName.TabIndex = 7;
            // 
            // comboRole
            // 
            comboRole.FormattingEnabled = true;
            comboRole.Items.AddRange(new object[] { "Staff", "Admin" });
            comboRole.Location = new Point(65, 296);
            comboRole.Name = "comboRole";
            comboRole.Size = new Size(135, 23);
            comboRole.TabIndex = 10;
            // 
            // textUser
            // 
            textUser.BorderStyle = BorderStyle.FixedSingle;
            textUser.Location = new Point(263, 262);
            textUser.Name = "textUser";
            textUser.Size = new Size(175, 23);
            textUser.TabIndex = 11;
            // 
            // textPass
            // 
            textPass.BorderStyle = BorderStyle.FixedSingle;
            textPass.Location = new Point(263, 296);
            textPass.Name = "textPass";
            textPass.PasswordChar = '*';
            textPass.Size = new Size(175, 23);
            textPass.TabIndex = 12;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(19, 367);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(102, 43);
            buttonAdd.TabIndex = 13;
            buttonAdd.Text = "เพิ่ม";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonRemove
            // 
            buttonRemove.Location = new Point(127, 367);
            buttonRemove.Name = "buttonRemove";
            buttonRemove.Size = new Size(102, 43);
            buttonRemove.TabIndex = 14;
            buttonRemove.Text = "ลบ";
            buttonRemove.UseVisualStyleBackColor = true;
            buttonRemove.Click += buttonRemove_Click;
            // 
            // buttonEdit
            // 
            buttonEdit.Location = new Point(235, 367);
            buttonEdit.Name = "buttonEdit";
            buttonEdit.Size = new Size(102, 43);
            buttonEdit.TabIndex = 15;
            buttonEdit.Text = "แก้ไข";
            buttonEdit.UseVisualStyleBackColor = true;
            buttonEdit.Click += buttonEdit_Click;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(343, 367);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(102, 43);
            buttonSave.TabIndex = 16;
            buttonSave.Text = "บันทึก";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // comboIsActive
            // 
            comboIsActive.FormattingEnabled = true;
            comboIsActive.Items.AddRange(new object[] { "พ้นสภาพพนักงาน", "เป็นพนักงาน" });
            comboIsActive.Location = new Point(65, 328);
            comboIsActive.Name = "comboIsActive";
            comboIsActive.Size = new Size(135, 23);
            comboIsActive.TabIndex = 17;
            // 
            // FormEmployee
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(457, 422);
            Controls.Add(comboIsActive);
            Controls.Add(buttonSave);
            Controls.Add(buttonEdit);
            Controls.Add(buttonRemove);
            Controls.Add(buttonAdd);
            Controls.Add(textPass);
            Controls.Add(textUser);
            Controls.Add(comboRole);
            Controls.Add(textName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(labelID);
            Controls.Add(dataGridView1);
            Name = "FormEmployee";
            Text = "ระบบจัดการพนักงาน";
            Load += FormEmployee_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label labelID;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textName;
        private ComboBox comboRole;
        private TextBox textUser;
        private TextBox textPass;
        private Button buttonAdd;
        private Button buttonRemove;
        private Button buttonEdit;
        private Button buttonSave;
        private ComboBox comboIsActive;
    }
}