﻿using Group3_DatabasePrograming_Project.Data;
using Group3_DatabasePrograming_Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormMember : Form
    {
        private bool editmode = false;
        private int selecting = 0;
        public FormMember()
        {
            InitializeComponent();
        }

        private void FormMember_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.MultiSelect = true;
            DataLoad();
            btnSave.Enabled = false;
        }

        private void DataLoad()
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var c = db.Customers.ToList();
                    dataGridView1.DataSource = c;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearForm()
        {
            labelID.Text = "รหัสสมาชิก: N/A";
            textLName.Text = "";
            textName.Text = "";
            textEmail.Text = "";
            textPhone.Text = "";
            textAddress.Text = "";
            textTaxAddress.Text = "";
        }

        private bool ValidateInput(out int points)
        {
            points = 0;
            if (string.IsNullOrEmpty(textName.Text))
            {
                MessageBox.Show("กรุณากรอกชื่อจริง");
                return false;
            }
            if (string.IsNullOrEmpty(textLName.Text))
            {
                MessageBox.Show("กรุณากรอกนามสกุล");
                return false;
            }
            if (string.IsNullOrEmpty(textEmail.Text))
            {
                MessageBox.Show("กรุณากรอก Email");
                return false;
            }
            if (string.IsNullOrEmpty(textPhone.Text))
            {
                MessageBox.Show("กรุณากรอกเบอร์โทรศํพท์");
                return false;
            }
            if (string.IsNullOrEmpty(textAddress.Text))
            {
                MessageBox.Show("กรุณากรอกที่อยู่");
                return false;
            }
            if (string.IsNullOrEmpty(textTaxAddress.Text))
            {
                MessageBox.Show("กรุณากรอกที่อยู่ใบเสร็จ");
                return false;
            }
            if (!int.TryParse(textPoints.Text, out points))
            {
                MessageBox.Show("กรุณาระบุคะแนน");
                return false;
            }
            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int point = 0;
            if (ValidateInput(out point))
            {

                try
                {
                    using (var db = new ToySellerContext())
                    {
                        var newMember = new Customer
                        {
                            CustomerFirstName = textName.Text.Trim(),
                            CustomerLastName = textLName.Text.Trim(),
                            CustomerEmail = textEmail.Text.Trim(),
                            CustomerPhone = textPhone.Text.Trim(),
                            CustomerAddress = textAddress.Text.Trim(),
                            CustomerTaxAddress = textTaxAddress.Text.Trim(),
                            CustomerPoints = point,
                            IsActive = checkIsActive.Checked,
                        };
                        db.Customers.Add(newMember);
                        db.SaveChanges();
                    }
                    clearForm();
                    DataLoad();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    var row = dataGridView1.Rows[e.RowIndex];
                    selecting = Convert.ToInt16(row.Cells["CustomerId"].Value);
                    using (var db = new ToySellerContext())
                    {
                        var p = db.Customers.Find(selecting);
                        if (p != null)
                        {
                            labelID.Text = "รหัสสมาชิก: " + p.CustomerId.ToString();
                            textName.Text = p.CustomerFirstName;
                            textLName.Text = p.CustomerLastName;
                            textEmail.Text = p.CustomerEmail;
                            textAddress.Text = p.CustomerAddress;
                            textPhone.Text = p.CustomerPhone;
                            textPoints.Text = p.CustomerPoints.ToString();
                            checkIsActive.Checked = p.IsActive;
                            textTaxAddress.Text = p.CustomerTaxAddress;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void checkSameLocation_CheckedChanged(object sender, EventArgs e)
        {
            if (checkSameLocation.Checked)
            {
                textTaxAddress.Text = textAddress.Text;
            }
            else
            {
                textTaxAddress.Text = "";
            }
        }

        private void textAddress_TextChanged(object sender, EventArgs e)
        {
            if (checkSameLocation.Checked)
            {
                textTaxAddress.Text = textAddress.Text;
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (selecting == 0)
            {
                MessageBox.Show("กรุณาเลือกรายการที่จะลบ");
                return;
            }
            try
            {
                if (MessageBox.Show("ยืนยันการลบ?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    using (var db = new ToySellerContext())
                    {
                        var c = db.Customers.Find(selecting);
                        if (c != null)
                        {
                            db.Customers.Remove(c);
                            db.SaveChanges();
                            DataLoad();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (editmode)
            {
                editmode = false;
                btnEdit.Text = "โหมดแก้ไข";
                btnSave.Enabled = false;
                btnAdd.Enabled = true;
                btnRemove.Enabled = true;
            }
            else
            {
                editmode = true;
                btnEdit.Text = "ยกเลิก";
                btnSave.Enabled = true;
                btnAdd.Enabled = false;
                btnRemove.Enabled = false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (selecting != 0)
            {
                int point = 0;
                if (ValidateInput(out point))
                {
                    try
                    {
                        using (var db = new ToySellerContext())
                        {
                            var c = db.Customers.Find(selecting);
                            {
                                c.CustomerFirstName = textName.Text.Trim();
                                c.CustomerLastName = textLName.Text.Trim();
                                c.CustomerEmail = textEmail.Text.Trim();
                                c.CustomerPhone = textPhone.Text.Trim();
                                c.CustomerAddress = textAddress.Text.Trim();
                                c.CustomerTaxAddress = textTaxAddress.Text.Trim();
                                c.CustomerPoints = point;
                                c.IsActive = checkIsActive.Checked;
                            }
                            ;
                            db.SaveChanges();
                        }
                        clearForm();
                        DataLoad();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            string filter = textSearch.Text.Trim();
            try
            {
                using (var db = new ToySellerContext())
                {
                    var c = db.Customers.Where(p => p.CustomerFirstName.Contains(filter)).ToList();
                    dataGridView1.DataSource = c;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnResetFil_Click(object sender, EventArgs e)
        {
            textFilMin.Text = "";
            textFilMax.Text = "";
            DataLoad();
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            using (var db = new ToySellerContext())
            {
                var c = db.Customers.AsQueryable();

                if (int.TryParse(textFilMin.Text, out int min))
                {
                    c = c.Where(c => c.CustomerPoints >= Convert.ToDecimal(min));
                }
                if (int.TryParse(textFilMax.Text, out int max))
                {
                    c = c.Where(c => c.CustomerPoints <= Convert.ToDecimal(max));
                }
                var result = c.ToList();
                dataGridView1.DataSource = result;
            }
        }
    }
}
