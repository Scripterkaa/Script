﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btnRegister = new Button();
            textFName = new TextBox();
            textLName = new TextBox();
            textPhone = new TextBox();
            textEmail = new TextBox();
            textAddress = new TextBox();
            textTaxAddress = new TextBox();
            checkSameLocation = new CheckBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(22, 93);
            label1.Name = "label1";
            label1.Size = new Size(52, 21);
            label1.TabIndex = 0;
            label1.Text = "ชื่อจริง:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 21F);
            label2.Location = new Point(22, 28);
            label2.Name = "label2";
            label2.Size = new Size(159, 38);
            label2.TabIndex = 1;
            label2.Text = "สมัครสมาชิก:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(22, 132);
            label3.Name = "label3";
            label3.Size = new Size(66, 21);
            label3.TabIndex = 2;
            label3.Text = "นามสกุล:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(22, 174);
            label4.Name = "label4";
            label4.Size = new Size(93, 21);
            label4.TabIndex = 3;
            label4.Text = "เบอร์โทรศัพท์:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(22, 213);
            label5.Name = "label5";
            label5.Size = new Size(43, 21);
            label5.TabIndex = 4;
            label5.Text = "อีเมล:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F);
            label6.Location = new Point(22, 286);
            label6.Name = "label6";
            label6.Size = new Size(70, 21);
            label6.TabIndex = 5;
            label6.Text = "ที่อยู่จัดส่ง:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F);
            label7.Location = new Point(22, 328);
            label7.Name = "label7";
            label7.Size = new Size(104, 21);
            label7.TabIndex = 6;
            label7.Text = "ที่อยู่ออกใบเสร็จ:";
            // 
            // btnRegister
            // 
            btnRegister.Font = new Font("Segoe UI", 13F);
            btnRegister.Location = new Point(106, 373);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(139, 44);
            btnRegister.TabIndex = 7;
            btnRegister.Text = "สมัคร";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // textFName
            // 
            textFName.BorderStyle = BorderStyle.FixedSingle;
            textFName.Location = new Point(80, 93);
            textFName.Name = "textFName";
            textFName.Size = new Size(251, 23);
            textFName.TabIndex = 8;
            // 
            // textLName
            // 
            textLName.BorderStyle = BorderStyle.FixedSingle;
            textLName.Location = new Point(90, 132);
            textLName.Name = "textLName";
            textLName.Size = new Size(241, 23);
            textLName.TabIndex = 9;
            // 
            // textPhone
            // 
            textPhone.BorderStyle = BorderStyle.FixedSingle;
            textPhone.Location = new Point(121, 174);
            textPhone.Name = "textPhone";
            textPhone.Size = new Size(210, 23);
            textPhone.TabIndex = 10;
            // 
            // textEmail
            // 
            textEmail.BorderStyle = BorderStyle.FixedSingle;
            textEmail.Location = new Point(71, 213);
            textEmail.Name = "textEmail";
            textEmail.Size = new Size(260, 23);
            textEmail.TabIndex = 11;
            // 
            // textAddress
            // 
            textAddress.BorderStyle = BorderStyle.FixedSingle;
            textAddress.Location = new Point(93, 286);
            textAddress.Name = "textAddress";
            textAddress.Size = new Size(238, 23);
            textAddress.TabIndex = 12;
            textAddress.TextChanged += textAddress_TextChanged;
            // 
            // textTaxAddress
            // 
            textTaxAddress.BorderStyle = BorderStyle.FixedSingle;
            textTaxAddress.Location = new Point(132, 326);
            textTaxAddress.Name = "textTaxAddress";
            textTaxAddress.Size = new Size(199, 23);
            textTaxAddress.TabIndex = 13;
            // 
            // checkSameLocation
            // 
            checkSameLocation.AutoSize = true;
            checkSameLocation.Location = new Point(22, 251);
            checkSameLocation.Name = "checkSameLocation";
            checkSameLocation.Size = new Size(80, 19);
            checkSameLocation.TabIndex = 14;
            checkSameLocation.Text = "ที่อยู่เดียวกัน";
            checkSameLocation.UseVisualStyleBackColor = true;
            checkSameLocation.CheckedChanged += checkSameLocation_CheckedChanged;
            // 
            // FormRegister
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(348, 439);
            Controls.Add(checkSameLocation);
            Controls.Add(textTaxAddress);
            Controls.Add(textAddress);
            Controls.Add(textEmail);
            Controls.Add(textPhone);
            Controls.Add(textLName);
            Controls.Add(textFName);
            Controls.Add(btnRegister);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormRegister";
            Text = "สมัครสมาชิก";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btnRegister;
        private TextBox textFName;
        private TextBox textLName;
        private TextBox textPhone;
        private TextBox textEmail;
        private TextBox textAddress;
        private TextBox textTaxAddress;
        private CheckBox checkSameLocation;
    }
}