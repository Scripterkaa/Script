﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            labelID = new Label();
            textName = new TextBox();
            textCategory = new TextBox();
            textManu = new TextBox();
            textDes = new TextBox();
            textCost = new TextBox();
            textPrice = new TextBox();
            textQty = new TextBox();
            btnAdd = new Button();
            btnEdit = new Button();
            btnRemove = new Button();
            label11 = new Label();
            textSearch = new TextBox();
            comboStatus = new ComboBox();
            btnSave = new Button();
            label10 = new Label();
            label12 = new Label();
            label13 = new Label();
            btnSearch = new Button();
            textFilMin = new TextBox();
            label14 = new Label();
            textFilMax = new TextBox();
            comboFilStatus = new ComboBox();
            label15 = new Label();
            label16 = new Label();
            textEXP = new TextBox();
            label17 = new Label();
            btnReset = new Button();
            comboCat = new ComboBox();
            pictureBox1 = new PictureBox();
            btnBrowse = new Button();
            label9 = new Label();
            label18 = new Label();
            textHowto = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 42);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(532, 226);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dgv_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 283);
            label1.Name = "label1";
            label1.Size = new Size(48, 15);
            label1.TabIndex = 1;
            label1.Text = "ชื่อสินค้า:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 312);
            label2.Name = "label2";
            label2.Size = new Size(50, 15);
            label2.TabIndex = 2;
            label2.Text = "หมวดหมู่:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 341);
            label3.Name = "label3";
            label3.Size = new Size(83, 15);
            label3.TabIndex = 3;
            label3.Text = "รายละเอียดสินค้า:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(156, 373);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 4;
            label4.Text = "วันผลิต:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(343, 283);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 5;
            label5.Text = "ต้นทุนสินค้า:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(343, 312);
            label6.Name = "label6";
            label6.Size = new Size(50, 15);
            label6.TabIndex = 6;
            label6.Text = "ราคาขาย:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 373);
            label7.Name = "label7";
            label7.Size = new Size(44, 15);
            label7.TabIndex = 7;
            label7.Text = "คงเหลือ:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(472, 372);
            label8.Name = "label8";
            label8.Size = new Size(64, 15);
            label8.TabIndex = 8;
            label8.Text = "สถานะสินค้า:";
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Font = new Font("Segoe UI", 16F);
            labelID.Location = new Point(12, 7);
            labelID.Name = "labelID";
            labelID.Size = new Size(145, 30);
            labelID.TabIndex = 9;
            labelID.Text = "รหัสสินค้า: N/A";
            // 
            // textName
            // 
            textName.BorderStyle = BorderStyle.FixedSingle;
            textName.Location = new Point(72, 279);
            textName.Name = "textName";
            textName.Size = new Size(256, 23);
            textName.TabIndex = 10;
            // 
            // textCategory
            // 
            textCategory.BorderStyle = BorderStyle.FixedSingle;
            textCategory.Location = new Point(72, 308);
            textCategory.Name = "textCategory";
            textCategory.Size = new Size(256, 23);
            textCategory.TabIndex = 11;
            // 
            // textManu
            // 
            textManu.BorderStyle = BorderStyle.FixedSingle;
            textManu.Location = new Point(204, 371);
            textManu.Name = "textManu";
            textManu.Size = new Size(90, 23);
            textManu.TabIndex = 12;
            // 
            // textDes
            // 
            textDes.BorderStyle = BorderStyle.FixedSingle;
            textDes.Location = new Point(101, 337);
            textDes.Name = "textDes";
            textDes.Size = new Size(226, 23);
            textDes.TabIndex = 13;
            // 
            // textCost
            // 
            textCost.BorderStyle = BorderStyle.FixedSingle;
            textCost.Location = new Point(412, 279);
            textCost.Name = "textCost";
            textCost.Size = new Size(253, 23);
            textCost.TabIndex = 14;
            // 
            // textPrice
            // 
            textPrice.BorderStyle = BorderStyle.FixedSingle;
            textPrice.Location = new Point(412, 308);
            textPrice.Name = "textPrice";
            textPrice.Size = new Size(253, 23);
            textPrice.TabIndex = 15;
            // 
            // textQty
            // 
            textQty.BorderStyle = BorderStyle.FixedSingle;
            textQty.Location = new Point(62, 369);
            textQty.Name = "textQty";
            textQty.Size = new Size(72, 23);
            textQty.TabIndex = 16;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(679, 243);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(153, 35);
            btnAdd.TabIndex = 22;
            btnAdd.Text = "เพิ่มสินค้า";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(679, 325);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(153, 35);
            btnEdit.TabIndex = 23;
            btnEdit.Text = "โหมดแก้ไขสินค้า";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(678, 284);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(153, 35);
            btnRemove.TabIndex = 24;
            btnRemove.Text = "ลบสินค้า";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11F);
            label11.Location = new Point(325, 9);
            label11.Name = "label11";
            label11.Size = new Size(96, 20);
            label11.TabIndex = 25;
            label11.Text = "ค้นหาชื่อสินค้า:";
            // 
            // textSearch
            // 
            textSearch.BorderStyle = BorderStyle.FixedSingle;
            textSearch.Location = new Point(427, 9);
            textSearch.Name = "textSearch";
            textSearch.Size = new Size(241, 23);
            textSearch.TabIndex = 26;
            textSearch.TextChanged += textSearch_TextChanged;
            // 
            // comboStatus
            // 
            comboStatus.FormattingEnabled = true;
            comboStatus.Items.AddRange(new object[] { "พร้อมขาย", "ไม่พร้อมขาย", "ยกเลิกการขายถาวร" });
            comboStatus.Location = new Point(542, 368);
            comboStatus.Name = "comboStatus";
            comboStatus.Size = new Size(122, 23);
            comboStatus.TabIndex = 28;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(679, 365);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(153, 35);
            btnSave.TabIndex = 29;
            btnSave.Text = "บันทึก";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F);
            label10.Location = new Point(679, 16);
            label10.Name = "label10";
            label10.Size = new Size(78, 21);
            label10.TabIndex = 30;
            label10.Text = "กรองสินค้า:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(679, 42);
            label12.Name = "label12";
            label12.Size = new Size(50, 15);
            label12.TabIndex = 32;
            label12.Text = "หมวดหมู่:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(679, 86);
            label13.Name = "label13";
            label13.Size = new Size(49, 15);
            label13.TabIndex = 33;
            label13.Text = "ช่วงราคา:";
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(678, 180);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(76, 25);
            btnSearch.TabIndex = 34;
            btnSearch.Text = "ค้นหา";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // textFilMin
            // 
            textFilMin.BorderStyle = BorderStyle.FixedSingle;
            textFilMin.Location = new Point(679, 104);
            textFilMin.Name = "textFilMin";
            textFilMin.Size = new Size(63, 23);
            textFilMin.TabIndex = 35;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 13F);
            label14.Location = new Point(748, 102);
            label14.Name = "label14";
            label14.Size = new Size(19, 25);
            label14.TabIndex = 36;
            label14.Text = "-";
            // 
            // textFilMax
            // 
            textFilMax.BorderStyle = BorderStyle.FixedSingle;
            textFilMax.Location = new Point(769, 104);
            textFilMax.Name = "textFilMax";
            textFilMax.Size = new Size(63, 23);
            textFilMax.TabIndex = 37;
            // 
            // comboFilStatus
            // 
            comboFilStatus.FormattingEnabled = true;
            comboFilStatus.Items.AddRange(new object[] { "พร้อมขาย", "ไม่พร้อมขาย", "ยกเลิกการขายถาวร" });
            comboFilStatus.Location = new Point(679, 151);
            comboFilStatus.Name = "comboFilStatus";
            comboFilStatus.Size = new Size(153, 23);
            comboFilStatus.TabIndex = 39;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(678, 133);
            label15.Name = "label15";
            label15.Size = new Size(64, 15);
            label15.TabIndex = 38;
            label15.Text = "สถานะสินค้า:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 12F);
            label16.Location = new Point(678, 219);
            label16.Name = "label16";
            label16.Size = new Size(81, 21);
            label16.TabIndex = 40;
            label16.Text = "แก้ไขสินค้า:";
            // 
            // textEXP
            // 
            textEXP.BorderStyle = BorderStyle.FixedSingle;
            textEXP.Location = new Point(369, 370);
            textEXP.Name = "textEXP";
            textEXP.Size = new Size(97, 23);
            textEXP.TabIndex = 42;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(304, 373);
            label17.Name = "label17";
            label17.Size = new Size(60, 15);
            label17.TabIndex = 41;
            label17.Text = "วันหมดอายุ:";
            // 
            // btnReset
            // 
            btnReset.Location = new Point(760, 180);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(72, 25);
            btnReset.TabIndex = 43;
            btnReset.Text = "รีเซ็ต";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // comboCat
            // 
            comboCat.FormattingEnabled = true;
            comboCat.Location = new Point(678, 60);
            comboCat.Name = "comboCat";
            comboCat.Size = new Size(153, 23);
            comboCat.TabIndex = 44;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(550, 104);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(115, 106);
            pictureBox1.TabIndex = 45;
            pictureBox1.TabStop = false;
            // 
            // btnBrowse
            // 
            btnBrowse.Location = new Point(550, 215);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(115, 25);
            btnBrowse.TabIndex = 46;
            btnBrowse.Text = "เลือกรูปภาพ";
            btnBrowse.UseVisualStyleBackColor = true;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F);
            label9.Location = new Point(550, 80);
            label9.Name = "label9";
            label9.Size = new Size(93, 21);
            label9.TabIndex = 47;
            label9.Text = "ตัวอย่างสินค้า:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(343, 341);
            label18.Name = "label18";
            label18.Size = new Size(65, 15);
            label18.TabIndex = 48;
            label18.Text = "วิธีการใช้งาน:";
            // 
            // textHowto
            // 
            textHowto.BorderStyle = BorderStyle.FixedSingle;
            textHowto.Location = new Point(411, 337);
            textHowto.Name = "textHowto";
            textHowto.Size = new Size(254, 23);
            textHowto.TabIndex = 49;
            // 
            // FormProduct
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(839, 407);
            Controls.Add(textHowto);
            Controls.Add(label18);
            Controls.Add(label9);
            Controls.Add(btnBrowse);
            Controls.Add(pictureBox1);
            Controls.Add(comboCat);
            Controls.Add(btnReset);
            Controls.Add(textEXP);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(comboFilStatus);
            Controls.Add(label15);
            Controls.Add(textFilMax);
            Controls.Add(label14);
            Controls.Add(textFilMin);
            Controls.Add(btnSearch);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(btnSave);
            Controls.Add(comboStatus);
            Controls.Add(textSearch);
            Controls.Add(label11);
            Controls.Add(btnRemove);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(textQty);
            Controls.Add(textPrice);
            Controls.Add(textCost);
            Controls.Add(textDes);
            Controls.Add(textManu);
            Controls.Add(textCategory);
            Controls.Add(textName);
            Controls.Add(labelID);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "FormProduct";
            Text = "จัดการสินค้า";
            Load += FormProduct_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label labelID;
        private TextBox textName;
        private TextBox textCategory;
        private TextBox textManu;
        private TextBox textDes;
        private TextBox textCost;
        private TextBox textPrice;
        private TextBox textQty;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnRemove;
        private Label label11;
        private TextBox textSearch;
        private ComboBox comboStatus;
        private Button btnSave;
        private Label label10;
        private Label label12;
        private Label label13;
        private Button btnSearch;
        private TextBox textFilMin;
        private Label label14;
        private TextBox textFilMax;
        private ComboBox comboFilStatus;
        private Label label15;
        private Label label16;
        private TextBox textEXP;
        private Label label17;
        private Button btnReset;
        private ComboBox comboCat;
        private PictureBox pictureBox1;
        private Button btnBrowse;
        private Label label9;
        private Label label18;
        private TextBox textHowto;
    }
}