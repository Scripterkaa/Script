﻿using Group3_DatabasePrograming_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormUserPanel : Form
    {
        public FormUserPanel()
        {
            InitializeComponent();
        }

        private void buttonShop_Click(object sender, EventArgs e)
        {
            FormShop frm = new FormShop();
            frm.ShowDialog();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            using (LoginForm frm = new LoginForm())
            {
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    string username = frm.user;
                    string password = frm.pass;

                    using(var db = new ToySellerContext())
                    {
                        var a = db.Employees.Where(a=>a.Username == username).Where(a=>a.Password == password).Where(a=>a.IsActive == true).FirstOrDefault();
                        if (a != null)
                        {
                            bool isadmin = false;
                            if (a.Role == "Admin")
                            {
                                isadmin = true;
                            }
                            StaffPanel sfrm = new StaffPanel(isadmin);
                            sfrm.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("ไม่พบ");
                        }
                    }
                }
            }
        }
    }
}
