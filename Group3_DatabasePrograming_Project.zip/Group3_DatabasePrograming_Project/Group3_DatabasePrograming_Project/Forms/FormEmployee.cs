﻿using Group3_DatabasePrograming_Project.Data;
using Group3_DatabasePrograming_Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormEmployee : Form
    {
        public FormEmployee()
        {
            InitializeComponent();
        }
        private int selecting = 0;
        private bool editmode = false;

        private void FormEmployee_Load(object sender, EventArgs e)
        {
            DataLoad();
            ClearForm();
            buttonSave.Enabled = false;
        }

        private void DataLoad()
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var e = db.Employees.ToList();
                    dataGridView1.DataSource = e;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearForm()
        {
            labelID.Text = "รหัสพนักงาน: N/A";
            textName.Text = "";
            textPass.Text = "";
            textUser.Text = "";
            comboIsActive.SelectedIndex = -1;
            comboRole.SelectedIndex = -1;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrEmpty(textName.Text))
            {
                MessageBox.Show("กรุณากรอกชื่อจริง");
                return false;
            }
            if (string.IsNullOrEmpty(textUser.Text))
            {
                MessageBox.Show("กรุณากรอก Username");
                return false;
            }
            if (string.IsNullOrEmpty(textPass.Text))
            {
                MessageBox.Show("กรุณากรอก Password");
                return false;
            }
            if (string.IsNullOrEmpty(comboIsActive.Text))
            {
                MessageBox.Show("กรุณาระบุสถานะ");
                return false;
            }
            if (string.IsNullOrEmpty(comboRole.Text))
            {
                MessageBox.Show("กรุณาระบุตำแหน่ง");
                return false;
            }

            return true;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) { return; }
            try
            {
                bool acti = false;
                if (comboIsActive.SelectedIndex == 1)
                {
                    acti = true;
                }
                using (var db = new ToySellerContext())
                {
                    var newEmp = new Employee
                    {
                        EmployeeFirstName = textName.Text.Trim(),
                        Username = textUser.Text.Trim(),
                        Password = textPass.Text.Trim(),
                        Role = comboRole.Text.Trim(),
                        IsActive = acti
                    };
                    db.Employees.Add(newEmp);
                    db.SaveChanges();
                }
                ClearForm();
                DataLoad();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    var row = dataGridView1.Rows[e.RowIndex];
                    selecting = Convert.ToInt16(row.Cells["EmployeeId"].Value);
                    using (var db = new ToySellerContext())
                    {
                        var emp = db.Employees.Find(selecting);
                        if (emp != null)
                        {
                            labelID.Text = "รหัสพนักงาน: " + emp.EmployeeId;
                            textName.Text = emp.EmployeeFirstName;
                            textPass.Text = emp.Password;
                            textUser.Text = emp.Username;
                            comboIsActive.SelectedIndex = Convert.ToInt32(emp.IsActive);
                            comboRole.Text = emp.Role;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (selecting == 0)
            {
                MessageBox.Show("กรุณาเลือกรายการที่จะลบ");
                return;
            }
            try
            {
                if (MessageBox.Show("ยืนยันการลบ?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    using (var db = new ToySellerContext())
                    {
                        var p = db.Employees.Find(selecting);
                        if (p != null)
                        {
                            db.Employees.Remove(p);
                            db.SaveChanges();
                            DataLoad();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (editmode)
            {
                editmode = false;
                buttonEdit.Text = "โหมดแก้ไขสินค้า";
                buttonSave.Enabled = false;
                buttonAdd.Enabled = true;
                buttonRemove.Enabled = true;
            }
            else
            {
                editmode = true;
                buttonEdit.Text = "ยกเลิก";
                buttonSave.Enabled = true;
                buttonAdd.Enabled = false;
                buttonRemove.Enabled = false;
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) { return; }
            bool acti = false;
            if (comboIsActive.SelectedIndex == 1)
            {
                acti = true;
            }
            try
            {

                using (var db = new ToySellerContext())
                {
                    var p = db.Employees.Find(selecting);
                    if (p != null)
                    {
                        p.EmployeeFirstName = textName.Text.Trim();
                        p.Username = textUser.Text.Trim();
                        p.Password = textPass.Text.Trim();
                        p.Role = comboRole.Text.Trim();
                        p.IsActive = acti;
                    }
                    ;
                    db.SaveChanges();
                }
                ClearForm();
                DataLoad();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
