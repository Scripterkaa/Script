﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class StaffPanel : Form
    {
        private bool admin = false;
        public StaffPanel(bool IsAdmin)
        {
            InitializeComponent();
            if (IsAdmin) { admin = true; }
        }

        private void StaffPanel_Load(object sender, EventArgs e)
        {
            if (admin)
            {
                btnEmployee.Enabled = true;
                btnMember.Enabled = true;
                btnProduct.Enabled = true;
                btnDashBoard.Enabled = true;
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            FormEmployee frm = new FormEmployee();
            frm.ShowDialog();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            FormMember frm = new FormMember();
            frm.ShowDialog();
        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
            FormDashboard frm = new FormDashboard();
            frm.ShowDialog();
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            FormProduct frm = new FormProduct();
            frm.ShowDialog();
        }

        private void btnStock_Click(object sender, EventArgs e)
        {
            FormStock frm = new FormStock();
            frm.ShowDialog();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            FormShop frm = new FormShop();
            frm.ShowDialog();
        }
    }
}
