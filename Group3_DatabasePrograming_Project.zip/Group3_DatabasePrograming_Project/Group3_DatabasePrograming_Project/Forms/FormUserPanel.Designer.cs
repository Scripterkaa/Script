﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormUserPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonShop = new Button();
            buttonLogin = new Button();
            SuspendLayout();
            // 
            // buttonShop
            // 
            buttonShop.Font = new Font("Segoe UI", 20F);
            buttonShop.Location = new Point(51, 24);
            buttonShop.Name = "buttonShop";
            buttonShop.Size = new Size(246, 64);
            buttonShop.TabIndex = 0;
            buttonShop.Text = "เลือกซื้อสินค้า";
            buttonShop.UseVisualStyleBackColor = true;
            buttonShop.Click += buttonShop_Click;
            // 
            // buttonLogin
            // 
            buttonLogin.Font = new Font("Segoe UI", 8F);
            buttonLogin.Location = new Point(51, 94);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(246, 26);
            buttonLogin.TabIndex = 1;
            buttonLogin.Text = "เข้าสู่ระบบ (เฉพาะพนักงาน)";
            buttonLogin.UseVisualStyleBackColor = true;
            buttonLogin.Click += buttonLogin_Click;
            // 
            // FormUserPanel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(340, 135);
            Controls.Add(buttonLogin);
            Controls.Add(buttonShop);
            Name = "FormUserPanel";
            Text = "ร้านขายของเล่น";
            ResumeLayout(false);
        }

        #endregion

        private Button buttonShop;
        private Button buttonLogin;
    }
}