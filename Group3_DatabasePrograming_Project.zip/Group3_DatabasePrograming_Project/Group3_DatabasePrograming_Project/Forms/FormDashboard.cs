﻿using Group3_DatabasePrograming_Project.Data;
using Group3_DatabasePrograming_Project.Models;
using iText.Kernel.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

namespace Group3_DatabasePrograming_Project.Forms
{
    public partial class FormDashboard : Form
    {
        public FormDashboard()
        {
            InitializeComponent();
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            DataLoad();
            comboFilter.SelectedIndex = 0;
        }

        private void DataLoad()
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var top1 = db.OrderDetails.GroupBy(t => t.ProductId).Select(g => new
                    {
                        ProductName = g.FirstOrDefault().Product.ProductName,
                        Total = g.Sum(c => c.Quantity)
                    }).OrderByDescending(x => x.Total).FirstOrDefault();
                    if (top1 != null) { }
                    labelTotal.Text = "ยอดขาย: " + db.Orders.Sum(o => o.Total).ToString() + "  บาท";
                    labelAmount.Text = "ขายไปแล้วจำนวน: " + db.OrderDetails.Sum(o => o.Quantity).ToString() + " ชิ้น";
                    labelBestSell.Text = "สินค้าขายดี: " + top1.ProductName;

                    labelMember.Text = "มีสมาชิกทั้งหมด: " + db.Customers.Count().ToString();
                    labelMostPoint.Text = "สมาชิกที่มีแต้มเยอะที่สุด: " + db.Customers.Where(p => p.IsActive == true).OrderByDescending(o => o.CustomerPoints).FirstOrDefault().CustomerFirstName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboFilter.SelectedIndex == 0)
            {
                DataLoad();
                dtMax.Enabled = false;
                dtMin.Enabled = false;
                buttonDateFil.Enabled = false;
            }
            else
            {
                dtMax.Enabled = true;
                dtMin.Enabled = true;
                buttonDateFil.Enabled = true;
            }
        }

        private void buttonDateFil_Click(object sender, EventArgs e)
        {
            try
            {
                using (var db = new ToySellerContext())
                {
                    var top1 = db.OrderDetails.Where(min => min.Order.OrderDate > dtMin.Value).Where(max => max.Order.OrderDate < dtMax.Value)
                        .GroupBy(t => t.ProductId).Select(g => new
                        {
                            ProductName = g.FirstOrDefault().Product.ProductName,
                            Total = g.Sum(c => c.Quantity)
                        }).OrderByDescending(x => x.Total).FirstOrDefault();
                    if (top1 != null)
                    {
                        labelTotal.Text = "ยอดขาย: " + db.Orders.Where(min => min.OrderDate > dtMin.Value).Where(max => max.OrderDate < dtMax.Value).Sum(o => o.Total).ToString() + "  บาท";
                        labelAmount.Text = "ขายไปแล้วจำนวน: " + db.OrderDetails.Where(min => min.Order.OrderDate > dtMin.Value).Where(max => max.Order.OrderDate < dtMax.Value).Sum(o => o.Quantity).ToString() + " ชิ้น";
                        labelBestSell.Text = "สินค้าขายดี: " + top1.ProductName;
                    }
                    else
                    {
                        MessageBox.Show("ไม่พอสินค้าในช่วงเวลานั้น");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PDF_SellHistory(string dmy)
        {
            string filePath = "ใบสรุปผลการขาย.pdf";

            using (PdfWriter writer = new PdfWriter(filePath))
            {
                using (PdfDocument pdf = new PdfDocument(writer))
                {
                    Document document = new Document(pdf);
                    string fontPath = @"C:\Users\PC\AppData\Local\Microsoft\Windows\Fonts\THSarabunNew.ttf";
                    PdfFont thaiFont = PdfFontFactory.CreateFont(fontPath, iText.IO.Font.PdfEncodings.IDENTITY_H);
                    document.SetFont(thaiFont);
                    string head = "";
                    string by = "";
                    if (dmy == "d") { head = "รายวัน"; by = "วันที่"; }
                    if (dmy == "m") { head = "รายเดือน"; by = "เดือน"; }
                    if (dmy == "y") { head = "รายปี"; by = "ปี"; }
                    Paragraph header = new Paragraph("ใบสรุปผลการขาย " + head)
                        .SetTextAlignment(TextAlignment.CENTER)
                        .SetFontSize(20);
                    document.Add(header);
                    document.Add(new Paragraph($"วันที่: {DateTime.Now:dd/MM/yyyy HH:mm}"));

                    Table table = new Table(4).UseAllAvailableWidth();
                    table.AddHeaderCell(by);
                    table.AddHeaderCell("จำนวน");
                    table.AddHeaderCell("รายรับ");
                    table.AddHeaderCell("กำไรสุทธิ");
                    using (var db = new ToySellerContext())
                    {
                        if (dmy == "d")
                        {
                            var _order = db.OrderDetails.Include(p => p.Product).Include(o => o.Order).GroupBy(x => x.Order.OrderDate.Date).Select(s => new
                            {
                                Date = s.Key,
                                TotalQty = s.Sum(x => x.Quantity),
                                TotalSales = s.Sum(x => x.Quantity * x.UnitPrice),
                                TotalProfit = s.Sum(x => x.Quantity * (x.UnitPrice - x.Product.CostPrice))
                            }).ToList();
                            foreach (var order in _order)
                            {
                                table.AddCell(order.Date.ToShortDateString());
                                table.AddCell(order.TotalQty.ToString("N0"));
                                table.AddCell(order.TotalSales.ToString("N2"));
                                table.AddCell(order.TotalProfit.ToString("N2"));
                            }
                        }
                        else if (dmy == "m")
                        {
                            var _order = db.OrderDetails.Include(p => p.Product).Include(o => o.Order).AsEnumerable()
                                .GroupBy(x => new { x.Order.OrderDate.Year, x.Order.OrderDate.Month }).Select(s => new
                                {
                                    Date = $"{s.Key.Month:D2}/{s.Key.Year}",
                                    TotalQty = s.Sum(x => x.Quantity),
                                    TotalSales = s.Sum(x => x.Quantity * x.UnitPrice),
                                    TotalProfit = s.Sum(x => x.Quantity * (x.UnitPrice - x.Product.CostPrice))
                                }).OrderByDescending(x => x.Date).ToList();
                            foreach (var order in _order)
                            {
                                table.AddCell(order.Date);
                                table.AddCell(order.TotalQty.ToString("N0"));
                                table.AddCell(order.TotalSales.ToString("N2"));
                                table.AddCell(order.TotalProfit.ToString("N2"));
                            }
                        }
                        else if (dmy == "y")
                        {
                            var _order = db.OrderDetails.Include(p => p.Product).Include(o => o.Order).AsEnumerable()
                                .GroupBy(x => new { x.Order.OrderDate.Year }).Select(s => new
                                {
                                    Date = $"{s.Key.Year}",
                                    TotalQty = s.Sum(x => x.Quantity),
                                    TotalSales = s.Sum(x => x.Quantity * x.UnitPrice),
                                    TotalProfit = s.Sum(x => x.Quantity * (x.UnitPrice - x.Product.CostPrice))
                                }).OrderByDescending(x => x.Date).ToList();
                            foreach (var order in _order)
                            {
                                table.AddCell(order.Date);
                                table.AddCell(order.TotalQty.ToString("N0"));
                                table.AddCell(order.TotalSales.ToString("N2"));
                                table.AddCell(order.TotalProfit.ToString("N2"));
                            }
                        }
                        else
                        {
                            return;
                        }

                        document.Add(table);
                        document.Close();
                    }
                }
            }
            MessageBox.Show("สร้างไฟล์ PDF เรียบร้อยที่: " + Path.GetFullPath(filePath));
        }

        private void buttonGetSellHistory_Click(object sender, EventArgs e)
        {
            PDF_SellHistory("d");
        }

        private void buttonMonth_Click(object sender, EventArgs e)
        {
            PDF_SellHistory("m");
        }

        private void buttonYear_Click(object sender, EventArgs e)
        {
            PDF_SellHistory("y");
        }
    }
}
