﻿namespace Group3_DatabasePrograming_Project.Forms
{
    partial class FormQR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            buttonOk = new Button();
            buttonCancel = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.ImageLocation = "C:\\Users\\PC\\Desktop\\visual project\\Group3_DatabasePrograming_Project\\Group3_DatabasePrograming_Project\\Image\\QR.png";
            pictureBox1.Location = new Point(62, 24);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(173, 166);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // buttonOk
            // 
            buttonOk.DialogResult = DialogResult.OK;
            buttonOk.Font = new Font("Segoe UI", 10F);
            buttonOk.Location = new Point(102, 222);
            buttonOk.Name = "buttonOk";
            buttonOk.Size = new Size(102, 33);
            buttonOk.TabIndex = 1;
            buttonOk.Text = "ชำระเงินแล้ว";
            buttonOk.UseVisualStyleBackColor = true;
            // 
            // buttonCancel
            // 
            buttonCancel.DialogResult = DialogResult.Cancel;
            buttonCancel.Font = new Font("Segoe UI", 10F);
            buttonCancel.Location = new Point(102, 261);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(102, 33);
            buttonCancel.TabIndex = 2;
            buttonCancel.Text = "ยกเลิก";
            buttonCancel.UseVisualStyleBackColor = true;
            // 
            // FormQR
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonCancel;
            ClientSize = new Size(295, 313);
            Controls.Add(buttonCancel);
            Controls.Add(buttonOk);
            Controls.Add(pictureBox1);
            Name = "FormQR";
            Text = "ชำระเงินผ่าน QR Code";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button buttonOk;
        private Button buttonCancel;
    }
}