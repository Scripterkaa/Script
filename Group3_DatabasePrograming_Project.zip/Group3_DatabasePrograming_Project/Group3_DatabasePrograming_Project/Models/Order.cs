﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group3_DatabasePrograming_Project.Models
{
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal Total {  get; set; }
        public bool IsMember { get; set; }
        [ForeignKey("CustomerId")]
        public int? CustomerId { get; set; }
        public Customer Customer { get; set; }
        [ForeignKey("GuestId")]
        public int? GuestId { get; set; }
        public Guest Guest { get; set; }
        public List<OrderDetail> SaleDetails { get; set; } = new List<OrderDetail>();
    }
}
