﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group3_DatabasePrograming_Project.Models
{
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        [ForeignKey("CategoryId")]
        public Category Category { get; set; }
        public string ProductDescription { get; set; }
        public string ProductHow {  get; set; }
        public DateOnly ManufactureDate { get; set; }
        public DateOnly ExpirationDate { get; set; }
        public decimal CostPrice { get; set; }
        public decimal SellingPrice { get; set; }
        public byte[]? ProductImage { get; set; }
        public int StockQty { get; set; }
        public string Status { get; set; }

    }
}
