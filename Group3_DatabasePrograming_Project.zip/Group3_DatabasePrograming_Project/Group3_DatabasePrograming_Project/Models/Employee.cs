﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group3_DatabasePrograming_Project.Models
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeId { get; set; }
        public string EmployeeFirstName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role {  get; set; }
        public bool IsActive { get; set; }
    }
}
